package com.example.michaeldonally.realityquest;

/**
 * Created by Michael Donally on 10/27/2016.
 */

public class Event {
    String name;
    boolean completed;
    String reward;
    String punishment;
    int exp;

    public void hasCompleted(){
        this.completed = true;
    }

    public Event(String n, String r, String p, int xp){
        this.name = n;
        this.completed = false;
        this.reward = r;
        this.punishment = p;
        this.exp = xp;
    }

    public String getName(){
        return this.name;
    }

    public boolean isCompleted() {
        return completed;
    }

    public String getReward() {
        return reward;
    }

    public String getPunishment() {
        return punishment;
    }

    public int getExp(){
        return exp;
    }
}
