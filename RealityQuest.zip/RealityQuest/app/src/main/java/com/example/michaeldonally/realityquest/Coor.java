package com.example.michaeldonally.realityquest;

/**
 * Created by Michael Donally on 10/27/2016.
 */

public class Coor {
    float longitude;
    float latitude;
}
